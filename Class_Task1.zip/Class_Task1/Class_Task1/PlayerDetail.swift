//
//  PlayerDetail.swift
//  Class_Task1
//
//  Created by Taibah Valley Academy on 3/9/25.
//

import SwiftUI

struct PlayerDetail: View {
    @ObservedObject var player: PlayerModel
    var body: some View {
        VStack {
            Text("Player Name: \(player.name)")
            Text("Player Score: \(player.score)")
            Text("Player Position: \(player.position)")
        }
    }
}
