//
//  AddingPlayerView.swift
//  Class_Task1
//
//  Created by Taibah Valley Academy on 3/9/25.
//

import SwiftUI

struct AddingPlayerView: View {
    @Environment(\.dismiss) private var dismiss // Allows dismissing the view
    @State private var name: String = ""
    @State private var score: String = ""
    @State private var position: String = ""
    
    var addPlayer: (String, Int, String) -> Void // Function to add a player

    var body: some View {
        NavigationStack {
            Form {
                TextField("Name", text: $name)
                TextField("Score", text: $score)
                TextField("Position", text: $position)
            }
            .navigationTitle("New Player")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Add") {
                        // Converts score string to Int before adding the player
                        if let scoreInt = Int(score) {
                            addPlayer(name, scoreInt, position)
                            dismiss() // Dismiss the add player screen after adding
                        }
                    }
                }
            }
        }
    }
}


