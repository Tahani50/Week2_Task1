//
//  PlayerModel.swift
//  Class_Task1
//
//  Created by Taibah Valley Academy on 3/9/25.
//


import SwiftUI

class PlayerModel: ObservableObject, Identifiable, Equatable {
    var id: UUID = UUID()
    @Published var name: String = ""
    @Published var score: Int = 0
    @Published var position: String = ""
    
    init(name: String, score: Int, position: String) {
        self.name = name
        self.score = score
        self.position = position
    }
    
    // Equatable conformance allows comparison between players
    static func == (lhs: PlayerModel, rhs: PlayerModel) -> Bool {
           return lhs.id == rhs.id
       }
}
