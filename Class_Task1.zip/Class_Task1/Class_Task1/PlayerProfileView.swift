//
//  PlayerProfileView.swift
//  Class_Task1
//
//  Created by Taibah Valley Academy on 3/9/25.
//

import SwiftUI

struct PlayerProfileView: View {
    
    // A state variable to store the list of players
    @State private var players: [PlayerModel] = [
        PlayerModel(name: "Tahani", score: 20, position: "Leader"),
        PlayerModel(name: "Alex", score: 15, position: "Member"),
    ]
    
    // Function to delete a player from the list with animation
    func deletePlayer(at indexSet: IndexSet) {
        withAnimation {
            players.remove(atOffsets: indexSet)
        }
    }
    
    // Function to add a new player to the list with animation
    func addPlayer(name: String, score: Int, position: String) {
        withAnimation {
            let newPlayer = PlayerModel(name: name, score: score, position: position)
            players.append(newPlayer)
        }
    }

    var body: some View {
        NavigationStack {
            List {
                ForEach(players) { player in
                    NavigationLink {
                        // Navigates to the player detail view
                        PlayerDetail(player: player)
                    } label: {
                        HStack {
                            Image(systemName: "person.circle")
                            Text("Name: \(player.name)").font(.headline)
                        }
                        .onTapGesture {
                            // Prints player name when tapped
                            print("\(player.name) tapped.")
                        }
                    }
                }
                .onDelete(perform: deletePlayer) // Enables swipe-to-delete functionality
                .animation(.default, value: players) // Animates adding/removing players
            }
            .navigationBarTitle("Player Profile")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    // Navigation link to open the "Add Player" view
                    NavigationLink(destination: AddingPlayerView(addPlayer: addPlayer)) {
                        Label("Add Player", systemImage: "plus")
                    }
                }
            }
        }
    }
}

#Preview {
    PlayerProfileView()
}

