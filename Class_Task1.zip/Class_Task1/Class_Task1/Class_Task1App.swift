//
//  Class_Task1App.swift
//  Class_Task1
//
//  Created by Taibah Valley Academy on 3/9/25.
//

import SwiftUI

@main
struct Class_Task1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
